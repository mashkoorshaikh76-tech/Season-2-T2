# Season 2 — Live Football Auction

## Publish on GitHub Pages
1. Open https://github.com/mashkoorshaikh76-tech/Season-2-T2
2. Tap **Add file → Upload files** and upload `index.html` from this ZIP.
3. Commit the file to `main`.
4. In **Settings → Pages**, choose **Deploy from a branch**, branch `main`, folder `/(root)`, then Save.
5. Wait a minute or two and open https://mashkoorshaikh76-tech.github.io/Season-2-T2/

## Firebase setup
The page is preconfigured for project `season-2-t2`. In Firebase Console, enable **Authentication → Sign-in method → Anonymous** and make sure Realtime Database exists in `asia-southeast1`.

`database.rules.example.json` is a temporary testing example only. It allows any signed-in user to read/write auction rooms, so it is NOT safe for public use. For trusted friends testing only, apply it in Realtime Database → Rules. For a public tournament, add server-side validation and proper host/room permissions first.

Features: 3 captains, default 5000 points each, up to 20 players, random order, live bids, squads, sale history, and losing-bid tax defaulting to 5% capped at 250 points per non-winning captain.
